/*==================== MENU SHOW Y HIDDEN ====================*/

let navToggleOpen = false;

function navToggle() {
	navToggleOpen = !navToggleOpen;
	if (navToggleOpen) {
		document.getElementById('nav__menu-mobile').classList.add('show-nav-mobile');
		document.getElementById('nav__menu-mobile').classList.add('nav-up');
		document.getElementById('nav__menu-mobile').classList.remove('nav-down');
		document.getElementById('nav-toggle').classList.add('active-nav');
		document.getElementById('nav-toggle').classList.remove('uil-apps');
		document.getElementById('nav-toggle').classList.add('uil-times');
	} else {
		document.getElementById('nav__menu-mobile').classList.remove('nav-up');
		document.getElementById('nav__menu-mobile').classList.add('nav-down');
		setTimeout(() => {
			document.getElementById('nav__menu-mobile').classList.remove('show-nav-mobile');
		}, 600);
		document.getElementById('nav-toggle').classList.remove('active-nav');
		document.getElementById('nav-toggle').classList.add('uil-apps');
		document.getElementById('nav-toggle').classList.remove('uil-times');
	}
}

document.getElementById('nav__link__home-mobile').addEventListener('click', () => {
	navToggle();
});
document.getElementById('nav__link__about-mobile').addEventListener('click', () => {
	navToggle();
});
document.getElementById('nav__link__skills-mobile').addEventListener('click', () => {
	navToggle();
});
document.getElementById('nav__link__portfolio-mobile').addEventListener('click', () => {
	navToggle();
});
document.getElementById('nav__link__services-mobile').addEventListener('click', () => {
	navToggle();
});
document.getElementById('nav__link__contact-mobile').addEventListener('click', () => {
	navToggle();
});

/*==================== LANGUAGE CHANGER ====================*/

let navLanguageOpen = false;

function navLanguage() {
	navLanguageOpen = !navLanguageOpen;
	if (navLanguageOpen) {
		document.getElementById('nav__language_letter-static').classList.add('active-lg');
		document.getElementById('nav__language_letter-changer').classList.add('active-lg');
		document.getElementById('nav__language_letter-changer').classList.remove('fa-e');
		document.getElementById('nav__language_letter-changer').classList.add('fa-s');

		/*==================== NAV ====================*/
		document.getElementById('home-lg').innerText = 'Inicio';
		document.getElementById('about-lg').innerText = 'Acerca de Mi';
		document.getElementById('skills-lg').innerText = 'Habilidades';
		document.getElementById('portfolio-lg').innerText = 'Portafolio';
		document.getElementById('services-lg').innerText = 'Servicios';
		document.getElementById('contact-lg').innerText = 'Contáctame';

		/*==================== HOME ====================*/
		document.getElementById('home__subtitle-lg').innerText = 'Desarrollador Front End, UX/UI';
		document.getElementById('home__description-lg1').innerText =
			'Busco conocer la perspectiva del cliente';
		document.getElementById('home__description-lg2').innerText =
			'dentro de la web, para aportar al desarrollo';
		document.getElementById('home__description-lg3').innerText =
			'desde una mejor experiencia de usuario';

		/*==================== ABOUT ====================*/
		document.getElementById('section__title__about-lg').innerText = 'Acerca de Mi';
		document.getElementById('about__description-lg').innerText = 'Un crack';
		document.getElementById('about__buttons-lg1').innerText = 'Descargar';

		/*==================== SKILLS ====================*/
		document.getElementById('section__title__skills-lg').innerText = 'Habilidades';

		/*==================== PORTFOLIO ====================*/
		document.getElementById('section__title__portfolio-lg').innerText = 'Portafolio';
		document.getElementById('section__subtitle__portfolio-lg').innerText = 'Trabajos recientes';
		document.getElementById('portfolio__container-lg-en').classList.remove('show-pf');
		document.getElementById('portfolio__container-lg-es').classList.add('show-pf');

		/*==================== SERVICES ====================*/
		document.getElementById('section__title__services-lg').innerText = 'Servicios';
		document.getElementById('section__title__services-front-lg').innerText = 'Desarrollador Front End';
		document.getElementById('service__front').innerText = 'Ver más';
		document.getElementById('services__modal-title-lg').innerText = 'Desarrollador Front End';
		document.getElementById('services__modal-services-front-lg1').innerText =
			'-Programar su página web desde el inicio.';
		document.getElementById('services__modal-services-front-lg2').innerText =
			'-Optimizar su interfaz para lograr que sea más intuitiva.';
		document.getElementById('services__modal-services-front-lg3').innerText =
			'-Recrear la relación de sus elementos visuales para mejorar la experiencia de usuario.';
		document.getElementById('service__design').innerText = 'Ver más';
		document.getElementById('services__modal-services-design-lg1').innerText =
			'-Diagramar el diseño de su página web.';
		document.getElementById('services__modal-services-design-lg2').innerText =
			'-Optimizar su interfaz para lograr que sea más intuitiva.';
		document.getElementById('services__modal-services-design-lg3').innerText =
			'-Recrear la relación de sus elementos visuales para mejorar la experiencia de usuario.';

		/*==================== CONTACT ====================*/
		document.getElementById('section__title__contact-lg').innerText = 'Contáctame';
		document.getElementById('section__subtitle__contact-lg').innerText = 'Envíame un mensaje';
		document.getElementById('contact__title-phone-lg').innerText = 'Celular';
		document.getElementById('contact__label-name-lg').innerText = 'Nombre/Empresa';
		document.getElementById('contact__label-message-lg').innerText = 'Mensaje';
		document.getElementById('contact__button-lg').innerText = 'Envíar';

		/*==================== FOOTER ====================*/
		document.getElementById('footer-lg').innerText = ' Nahuel Gimer. Todos los Derechos Reservados.';
	} else {
		document.getElementById('nav__language_letter-static').classList.remove('active-lg');
		document.getElementById('nav__language_letter-changer').classList.remove('active-lg');
		document.getElementById('nav__language_letter-changer').classList.add('fa-e');
		document.getElementById('nav__language_letter-changer').classList.remove('fa-s');

		/*==================== NAV ====================*/
		document.getElementById('home-lg').innerText = 'Home';
		document.getElementById('about-lg').innerText = 'About Me';
		document.getElementById('skills-lg').innerText = 'Skills';
		document.getElementById('portfolio-lg').innerText = 'Portfolio';
		document.getElementById('services-lg').innerText = 'Services';
		document.getElementById('contact-lg').innerText = 'Contact Me';

		/*==================== HOME ====================*/
		document.getElementById('home__subtitle-lg').innerText = 'Front End Developer, UX/UI';
		document.getElementById('home__description-lg1').innerText = 'Focused in learn the perspective';
		document.getElementById('home__description-lg2').innerText =
			'of the client or customer inside the web,';
		document.getElementById('home__description-lg3').innerText = 'to enhance their user experience.';

		/*==================== ABOUT ====================*/
		document.getElementById('section__title__about-lg').innerText = 'About Me';
		document.getElementById('about__description-lg').innerText = 'A crack';
		document.getElementById('about__buttons-lg1').innerText = 'Download';

		/*==================== SKILLS ====================*/
		document.getElementById('section__title__skills-lg').innerText = 'Skills';

		/*==================== PORTFOLIO ====================*/

		document.getElementById('section__title__portfolio-lg').innerText = 'Portfolio';
		document.getElementById('section__subtitle__portfolio-lg').innerText = 'Recent work';
		document.getElementById('portfolio__container-lg-es').classList.remove('show-pf');
		document.getElementById('portfolio__container-lg-en').classList.add('show-pf');

		/*==================== SERVICES ====================*/
		document.getElementById('section__title__services-lg').innerText = 'Services';
		document.getElementById('section__title__services-front-lg').innerText = 'Front End Developer';
		document.getElementById('service__front').innerText = 'View more';
		document.getElementById('services__modal-title-lg').innerText = 'Front End Developer';
		document.getElementById('services__modal-services-front-lg1').innerText =
			'-Program your web page from the beginning.';
		document.getElementById('services__modal-services-front-lg2').innerText =
			'-Optimice the user interface to make it more intuitive.';
		document.getElementById('services__modal-services-front-lg3').innerText =
			'-Recreate visual element interactions to get a better user experience.';
		document.getElementById('service__design').innerText = 'View more';
		document.getElementById('services__modal-services-design-lg1').innerText =
			'-Diagram the web page design.';
		document.getElementById('services__modal-services-design-lg2').innerText =
			'-Optimize the user interface.';
		document.getElementById('services__modal-services-design-lg3').innerText =
			'-Recreate UX element interactions.';

		/*==================== CONTACT ====================*/
		document.getElementById('section__title__contact-lg').innerText = 'Contact Me';
		document.getElementById('section__subtitle__contact-lg').innerText = 'Get in touch';
		document.getElementById('contact__title-phone-lg').innerText = 'Phone';
		document.getElementById('contact__label-name-lg').innerText = 'Name';
		document.getElementById('contact__label-message-lg').innerText = 'Message';
		document.getElementById('contact__button-lg').innerText = 'Send';

		/*==================== FOOTER ====================*/
		document.getElementById('footer-lg').innerText = ' Nahuel Gimer. All Rights Reserved.';
	}
}

/*==================== DARK LIGHT THEME ====================*/

let navThemeOpen = false;

function navTheme() {
	navThemeOpen = !navThemeOpen;
	if (navThemeOpen) {
		document.body.classList.add('dark-theme');
		document.getElementById('theme-button').classList.add('active-theme');
		document.getElementById('theme-button').classList.remove('uil-sun');
		document.getElementById('theme-button').classList.add('uil-moon');
	} else {
		document.body.classList.remove('dark-theme');
		document.getElementById('theme-button').classList.remove('active-theme');
		document.getElementById('theme-button').classList.add('uil-sun');
		document.getElementById('theme-button').classList.remove('uil-moon');
	}
}

/*==================== ACCORDION SKILLS ====================*/

let skills__frontOpen = false,
	skills__backOpen = false,
	skills__designOpen = false;

function skills__front() {
	skills__frontOpen = !skills__frontOpen;
	if (skills__frontOpen) {
		document.getElementById('skills__list-front').classList.add('skills-down');
		document.getElementById('skills__list-front').classList.remove('skills-up');
		document.getElementById('skills__front').classList.remove('skills__close');
		document.getElementById('skills__front').classList.add('skills__content');
		document.getElementById('skills__front').classList.add('skills__open');
		document.getElementById('skills__back').classList.remove('skills-return-back');
	} else {
		document.getElementById('skills__list-front').classList.add('skills-up');
		document.getElementById('skills__list-front').classList.remove('skills-down');
		document.getElementById('skills__front').classList.remove('skills__open');
		setTimeout(() => {
			document.getElementById('skills__front').classList.remove('skills__content');
			document.getElementById('skills__front').classList.add('skills__close');
		}, 200);
		document.getElementById('skills__back').classList.add('skills-return-back');
	}
}

function skills__back() {
	skills__backOpen = !skills__backOpen;
	if (skills__backOpen) {
		document.getElementById('skills__list-back').classList.add('skills-down');
		document.getElementById('skills__list-back').classList.remove('skills-up');
		document.getElementById('skills__back').classList.remove('skills__close');
		document.getElementById('skills__back').classList.add('skills__content');
		document.getElementById('skills__back').classList.add('skills__open');
		document.getElementById('skills__design').classList.remove('skills-return-design');
	} else {
		document.getElementById('skills__list-back').classList.add('skills-up');
		document.getElementById('skills__list-back').classList.remove('skills-down');
		document.getElementById('skills__back').classList.remove('skills__open');
		setTimeout(() => {
			document.getElementById('skills__back').classList.remove('skills__content');
			document.getElementById('skills__back').classList.add('skills__close');
		}, 200);
		document.getElementById('skills__design').classList.add('skills-return-design');
	}
}
function skills__design() {
	skills__designOpen = !skills__designOpen;
	if (skills__designOpen) {
		document.getElementById('skills__list-design').classList.add('skills-down');
		document.getElementById('skills__list-design').classList.remove('skills-up');
		document.getElementById('skills__design').classList.remove('skills__close');
		document.getElementById('skills__design').classList.add('skills__content');
		document.getElementById('skills__design').classList.add('skills__open');
	} else {
		document.getElementById('skills__list-design').classList.add('skills-up');
		document.getElementById('skills__list-design').classList.remove('skills-down');
		document.getElementById('skills__design').classList.remove('skills__open');
		setTimeout(() => {
			document.getElementById('skills__design').classList.remove('skills__content');
			document.getElementById('skills__design').classList.add('skills__close');
		}, 200);
	}
}
/*==================== QUALIFICATION TABS ====================*/

/*==================== SERVICES MODAL ====================*/

const layout = document.querySelectorAll('.services__modal');

document.getElementById('service__front').addEventListener('click', () => {
	document.getElementById('service__front-modal').classList.add('services-on');
	document.getElementById('service__front-modal').classList.remove('services-off');
	document.getElementById('service__front-modal').classList.add('layout');
	document.getElementById('service__front-modal').classList.add('show-modal');
});

document.getElementById('service__front-close').addEventListener('click', () => {
	setTimeout(() => {
		document.getElementById('service__front-modal').classList.remove('layout');
		document.getElementById('service__front-modal').classList.remove('show-modal');
	}, 300);
	document.getElementById('service__front-modal').classList.remove('services-on');
	document.getElementById('service__front-modal').classList.add('services-off');
});

document.getElementById('service__design').addEventListener('click', () => {
	document.getElementById('service__design-modal').classList.add('services-on');
	document.getElementById('service__design-modal').classList.remove('services-off');
	document.getElementById('service__design-modal').classList.add('layout');
	document.getElementById('service__design-modal').classList.add('show-modal');
});

document.getElementById('service__design-close').addEventListener('click', () => {
	setTimeout(() => {
		document.getElementById('service__design-modal').classList.remove('layout');
		document.getElementById('service__design-modal').classList.remove('show-modal');
	}, 300);
	document.getElementById('service__design-modal').classList.remove('services-on');
	document.getElementById('service__design-modal').classList.add('services-off');
});

/*==================== PORTFOLIO SWIPER  ====================*/

var swiper = new Swiper('.swiper', {
	slidesPerView: 1,
	centeredSlides: true,
	spaceBetween: 30,
	speed: 700,
	loop: true,
	autoplay: {
		delay: 904500,
		disableOnInteraction: false,
	},
	pagination: {
		el: '.swiper-pagination',
		clickable: true,
	},
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
	},
});

/*==================== TESTIMONIAL ====================*/

/*==================== SCROLL SECTIONS ACTIVE LINK ====================*/

const sections = document.querySelectorAll('section[id]');

function scrollActive() {
	const scrollY = window.pageYOffset;

	sections.forEach((current) => {
		const sectionHeight = current.offsetHeight;
		const sectionTop = current.offsetTop - 300;
		sectionId = current.getAttribute('id');

		if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
			document
				.querySelector('.nav__menu-mobile a[href*=' + sectionId + ']')
				.classList.add('active-link-mobile');
			document
				.querySelector('.nav__menu-desk a[href*=' + sectionId + ']')
				.classList.add('active-link-desk');
		} else {
			document
				.querySelector('.nav__menu-mobile a[href*=' + sectionId + ']')
				.classList.remove('active-link-mobile');
			document
				.querySelector('.nav__menu-desk a[href*=' + sectionId + ']')
				.classList.remove('active-link-desk');
		}
	});
}
window.addEventListener('scroll', scrollActive);

/*==================== CHANGE BACKGROUND HEADER ====================*/

function scrollNav() {
	const nav = document.getElementById('header');
	// When the scroll is greater than 200 viewport height, add the scroll-header class to the header tag
	if (this.scrollY >= 20) nav.classList.add('scroll-nav');
	else nav.classList.remove('scroll-nav');
}
window.addEventListener('scroll', scrollNav);

/*==================== SHOW SCROLL UP ====================*/

/*
function scrollUp() {
	const scrollUp = document.getElementById('scroll-up');
	// When the scroll is higher than 560 viewport height, add the show-scroll class to the a tag with the scroll-up class
	if (this.scrollY >= 560) scrollUp.classList.add('show-scroll');
	else scrollUp.classList.remove('show-scroll');
}
window.addEventListener('scroll', scrollUp);
*/

/*==================== EMAIL FORM ====================*/

/*var form = document.getElementById('form');

async function handleSubmit(event) {
	event.preventDefault();
	var status = document.getElementById('status');
	var data = new FormData(event.target);
	fetch(event.target.action, {
		method: form.method,
		body: data,
		headers: {
			Accept: 'application/json',
		},
	})
		.then((response) => {
			if (response.ok) {
				status.classList.add('success');
				status.innerHTML =
					'Thank you for your message. I will get in touch with you as soon as possible. ';
				form.reset();
				nameCheck.classList.remove('fa-solid');
				nameCheck.classList.remove('fa-check');
				nameCross.classList.remove('fa-solid');
				nameCross.classList.remove('fa-xmark');
				emailCheck.classList.remove('fa-check');
				emailCheck.classList.remove('fa-solid');
				emailCross.classList.remove('fa-solid');
				emailCross.classList.remove('fa-xmark');
				subjectCheck.classList.remove('fa-solid');
				subjectCheck.classList.remove('fa-check');
				subjectCross.classList.remove('fa-solid');
				subjectCross.classList.remove('fa-xmark');
				messageCheck.classList.remove('fa-solid');
				messageCheck.classList.remove('fa-check');
				messageCross.classList.remove('fa-solid');
				messageCross.classList.remove('fa-xmark');
			} else {
				response.json().then((data) => {
					if (Object.hasOwn(data, 'errors')) {
						status.innerHTML = data['errors'].map((error) => error['message']).join(', ');
					} else {
						status.classList.add('error');
						status.innerHTML =
							'Sorry, this form is currently being updated, please use the other contact forms to the left of this form to get in contact with me.';
					}
				});
			}
		})
		.catch((error) => {
			status.classList.add('error');
			status.innerHTML =
				'This form is currently being updated, please use the other contact forms to the left of this form.';
		});
}
form.addEventListener('submit', handleSubmit);

const contactFormName = document.getElementById('name');
const contactFormEmail = document.getElementById('email');
const contactFormSubject = document.getElementById('subject');
const contactFormMessage = document.getElementById('message');
const nameCheck = document.getElementById('nameCheck');
const nameCross = document.getElementById('nameCross');
const emailCheck = document.getElementById('emailCheck');
const emailCross = document.getElementById('emailCross');
const subjectCheck = document.getElementById('subjectCheck');
const subjectCross = document.getElementById('subjectCross');
const messageCheck = document.getElementById('messageCheck');
const messageCross = document.getElementById('messageCross');

contactFormName.addEventListener('click', () => {
	nameCheck.classList.add('fa-solid');
	nameCheck.classList.add('fa-check');
	nameCross.classList.add('fa-solid');
	nameCross.classList.add('fa-xmark');
});

contactFormEmail.addEventListener('click', () => {
	emailCheck.classList.add('fa-check');
	emailCheck.classList.add('fa-solid');
	emailCross.classList.add('fa-solid');
	emailCross.classList.add('fa-xmark');
});

contactFormSubject.addEventListener('click', () => {
	subjectCheck.classList.add('fa-solid');
	subjectCheck.classList.add('fa-check');
	subjectCross.classList.add('fa-solid');
	subjectCross.classList.add('fa-xmark');
});

contactFormMessage.addEventListener('click', () => {
	messageCheck.classList.add('fa-solid');
	messageCheck.classList.add('fa-check');
	messageCross.classList.add('fa-solid');
	messageCross.classList.add('fa-xmark');
});*/
